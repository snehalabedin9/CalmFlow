export type Mood = 'great' | 'good' | 'okay' | 'bad' | 'terrible';

export interface MoodEntry {
  id: string;
  date: Date;
  mood: Mood;
  note: string;
}

export interface JournalEntry {
  id: string;
  date: Date;
  content: string;
  tags: string[];
}

export interface ScheduleEvent {
  id: string;
  title: string;
  date: Date;
  startTime: string;
  endTime: string;
  category: 'school' | 'personal' | 'health' | 'other';
}