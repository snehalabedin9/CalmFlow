import React, { useState } from 'react';
import { Book, Tag, Trash2 } from 'lucide-react';
import type { JournalEntry } from '../types';

const Journal: React.FC = () => {
  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [newEntry, setNewEntry] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [newTag, setNewTag] = useState('');

  const handleAddEntry = () => {
    if (newEntry.trim()) {
      const entry: JournalEntry = {
        id: Date.now().toString(),
        date: new Date(),
        content: newEntry,
        tags: tags,
      };
      setEntries([entry, ...entries]);
      setNewEntry('');
      setTags([]);
    }
  };

  const handleAddTag = () => {
    if (newTag.trim() && !tags.includes(newTag.trim())) {
      setTags([...tags, newTag.trim()]);
      setNewTag('');
    }
  };

  const handleDeleteEntry = (entryId: string) => {
    setEntries(entries.filter(entry => entry.id !== entryId));
  };

  return (
    <div className="bg-gradient-to-br from-white/90 via-white/80 to-white/85 backdrop-blur-sm rounded-xl p-5 shadow-lg">
      <div className="flex items-center gap-2 mb-4">
        <Book className="w-5 h-5 text-cyan-600" />
        <h2 className="text-xl font-bold bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent">
          Journal
        </h2>
      </div>

      <div className="mb-4">
        <textarea
          value={newEntry}
          onChange={(e) => setNewEntry(e.target.value)}
          placeholder="Write your thoughts here..."
          className="w-full h-24 p-3 border rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent bg-white/50 resize-none text-sm"
        />
        
        <div className="flex items-center gap-2 mt-2">
          <Tag className="w-4 h-4 text-gray-500" />
          <input
            type="text"
            value={newTag}
            onChange={(e) => setNewTag(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleAddTag()}
            placeholder="Add tags"
            className="flex-1 p-2 border rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent bg-white/50 text-sm"
          />
        </div>

        <div className="flex flex-wrap gap-2 mt-2">
          {tags.map((tag) => (
            <span
              key={tag}
              className="px-3 py-1 bg-gradient-to-r from-cyan-100 to-blue-100 text-cyan-800 rounded-full text-xs"
            >
              #{tag}
            </span>
          ))}
        </div>

        <button
          onClick={handleAddEntry}
          className="mt-3 px-5 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 text-white rounded-lg hover:from-cyan-700 hover:to-blue-700 transition-all duration-200 text-sm"
        >
          Save Entry
        </button>
      </div>

      <div className="space-y-3">
        {entries.map((entry) => (
          <div key={entry.id} className="p-3 bg-white/90 rounded-lg group hover:shadow-md transition-all duration-200">
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs text-gray-500">
                {entry.date.toLocaleDateString()}
              </p>
              <button
                onClick={() => handleDeleteEntry(entry.id)}
                className="text-red-500 opacity-0 group-hover:opacity-100 transition-opacity duration-200"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
            <p className="text-gray-800 mb-2 whitespace-pre-wrap break-words text-sm">
              {entry.content}
            </p>
            <div className="flex flex-wrap gap-2">
              {entry.tags.map((tag) => (
                <span
                  key={tag}
                  className="px-2 py-1 bg-gradient-to-r from-cyan-100 to-blue-100 text-cyan-800 rounded-full text-xs"
                >
                  #{tag}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Journal;