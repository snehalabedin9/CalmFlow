import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { format } from 'date-fns';
import { SmilePlus, Trash2 } from 'lucide-react';
import type { Mood, MoodEntry } from '../types';

const moodEmojis = {
  'great': '😊',
  'good': '🙂',
  'okay': '😐',
  'bad': '😔',
  'terrible': '😢',
};

const moodToNumber = {
  'great': 5,
  'good': 4,
  'okay': 3,
  'bad': 2,
  'terrible': 1,
};

const MoodTracker: React.FC = () => {
  const [moodHistory, setMoodHistory] = useState<MoodEntry[]>([]);
  const [newNote, setNewNote] = useState('');
  const [selectedMood, setSelectedMood] = useState<Mood | null>(null);

  const handleAddMood = () => {
    if (selectedMood) {
      const newEntry: MoodEntry = {
        id: Date.now().toString(),
        date: new Date(),
        mood: selectedMood,
        note: newNote,
      };
      setMoodHistory([...moodHistory, newEntry]);
      setNewNote('');
      setSelectedMood(null);
    }
  };

  const handleDeleteMood = (date: Date) => {
    setMoodHistory(moodHistory.filter(entry => entry.date !== date));
  };

  const chartData = moodHistory
    .slice(-7)
    .map(entry => ({
      date: format(entry.date, 'MM/dd'),
      value: moodToNumber[entry.mood],
      mood: entry.mood,
      note: entry.note,
      originalDate: entry.date,
    }));

  return (
    <div className="bg-gradient-to-br from-white/90 via-white/80 to-white/85 backdrop-blur-sm rounded-xl p-5 shadow-lg">
      <div className="flex items-center gap-2 mb-4">
        <SmilePlus className="w-5 h-5 text-cyan-600" />
        <h2 className="text-xl font-bold bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent">
          Mood Tracker
        </h2>
      </div>

      <div className="mb-4">
        <div className="flex gap-3 mb-3">
          {(Object.keys(moodEmojis) as Mood[]).map((mood) => (
            <button
              key={mood}
              onClick={() => setSelectedMood(mood)}
              className={`p-3 rounded-lg transition-all transform hover:scale-110 ${
                selectedMood === mood 
                  ? 'bg-gradient-to-r from-cyan-100 to-blue-100 scale-110' 
                  : 'bg-white hover:bg-gradient-to-r hover:from-white hover:to-cyan-50'
              }`}
            >
              <span className="text-xl">{moodEmojis[mood]}</span>
              <p className="text-xs mt-1 capitalize">{mood}</p>
            </button>
          ))}
        </div>

        <textarea
          value={newNote}
          onChange={(e) => setNewNote(e.target.value)}
          placeholder="How are you feeling today?"
          className="w-full h-20 p-3 border rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent bg-white/50 resize-none text-sm"
        />

        <button
          onClick={handleAddMood}
          disabled={!selectedMood}
          className="mt-3 px-5 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 text-white rounded-lg hover:from-cyan-700 hover:to-blue-700 transition-all duration-200 disabled:opacity-50 text-sm"
        >
          Add Mood
        </button>
      </div>

      <div className="h-48">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData}>
            <XAxis dataKey="date" />
            <YAxis domain={[1, 5]} hide />
            <Tooltip
              content={({ active, payload }) => {
                if (active && payload && payload.length) {
                  const data = payload[0].payload;
                  return (
                    <div className="bg-white p-3 rounded-lg shadow-lg border">
                      <div className="flex items-center justify-between gap-3">
                        <p className="font-semibold text-sm">{data.date}</p>
                        <button
                          onClick={() => handleDeleteMood(data.originalDate)}
                          className="text-red-500 hover:text-red-600 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xl">{moodEmojis[data.mood as Mood]}</span>
                        <span className="capitalize text-sm">{data.mood}</span>
                      </div>
                      <p className="text-gray-600 mt-1 break-words text-sm">{data.note}</p>
                    </div>
                  );
                }
                return null;
              }}
            />
            <Bar
              dataKey="value"
              fill="url(#colorGradient)"
              radius={[4, 4, 0, 0]}
            />
            <defs>
              <linearGradient id="colorGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#0891b2" />
                <stop offset="100%" stopColor="#2563eb" />
              </linearGradient>
            </defs>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

export default MoodTracker;