import React, { useState } from 'react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isSameMonth } from 'date-fns';
import { Calendar as CalendarIcon, Plus, Trash2 } from 'lucide-react';
import type { ScheduleEvent } from '../types';

const Calendar: React.FC = () => {
  const [events, setEvents] = useState<ScheduleEvent[]>([]);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [showEventForm, setShowEventForm] = useState(false);
  const [newEvent, setNewEvent] = useState<Partial<ScheduleEvent>>({
    title: '',
    startTime: '',
    endTime: '',
    category: 'personal'
  });

  const handleAddEvent = () => {
    if (newEvent.title && newEvent.startTime && newEvent.endTime) {
      const event: ScheduleEvent = {
        id: Date.now().toString(),
        title: newEvent.title,
        date: selectedDate,
        startTime: newEvent.startTime,
        endTime: newEvent.endTime,
        category: newEvent.category || 'personal',
      };
      setEvents([...events, event]);
      setShowEventForm(false);
      setNewEvent({
        title: '',
        startTime: '',
        endTime: '',
        category: 'personal'
      });
    }
  };

  const handleDeleteEvent = (eventId: string) => {
    setEvents(events.filter(event => event.id !== eventId));
  };

  const monthStart = startOfMonth(selectedDate);
  const monthEnd = endOfMonth(selectedDate);
  const monthDays = eachDayOfInterval({ start: monthStart, end: monthEnd });

  const todayEvents = events.filter(event =>
    isSameDay(event.date, selectedDate)
  );

  return (
    <div className="bg-gradient-to-br from-white/90 via-white/80 to-white/85 backdrop-blur-sm rounded-xl p-5 shadow-lg">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <CalendarIcon className="w-5 h-5 text-cyan-600" />
          <h2 className="text-xl font-bold bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent">
            Calendar
          </h2>
        </div>
        <button
          onClick={() => setShowEventForm(!showEventForm)}
          className="p-2 text-cyan-600 hover:bg-cyan-50 rounded-lg transition-all duration-200"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>

      <div className="grid grid-cols-7 gap-1 mb-3">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
          <div key={day} className="text-center text-xs font-medium text-cyan-600">
            {day}
          </div>
        ))}
        {monthDays.map(day => {
          const dayEvents = events.filter(event => isSameDay(event.date, day));
          return (
            <button
              key={day.toString()}
              onClick={() => setSelectedDate(day)}
              className={`p-2 text-center rounded-lg transition-all duration-200 ${
                isSameDay(day, selectedDate)
                  ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white'
                  : isSameMonth(day, selectedDate)
                  ? 'hover:bg-cyan-50'
                  : 'text-gray-400'
              }`}
            >
              <div className="text-xs">{format(day, 'd')}</div>
              {dayEvents.length > 0 && (
                <div className="w-1 h-1 bg-cyan-400 rounded-full mx-auto mt-1" />
              )}
            </button>
          );
        })}
      </div>

      {showEventForm && (
        <div className="mb-4 p-3 bg-white/90 rounded-lg shadow-sm">
          <input
            type="text"
            value={newEvent.title}
            onChange={(e) => setNewEvent({ ...newEvent, title: e.target.value })}
            placeholder="Event title"
            className="w-full p-2 mb-2 border rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent text-sm"
          />
          <div className="grid grid-cols-2 gap-2 mb-2">
            <input
              type="time"
              value={newEvent.startTime}
              onChange={(e) => setNewEvent({ ...newEvent, startTime: e.target.value })}
              className="p-2 border rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent text-sm"
            />
            <input
              type="time"
              value={newEvent.endTime}
              onChange={(e) => setNewEvent({ ...newEvent, endTime: e.target.value })}
              className="p-2 border rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent text-sm"
            />
          </div>
          <select
            value={newEvent.category}
            onChange={(e) => setNewEvent({ ...newEvent, category: e.target.value as ScheduleEvent['category'] })}
            className="w-full p-2 mb-3 border rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent text-sm"
          >
            <option value="school">School</option>
            <option value="personal">Personal</option>
            <option value="health">Health</option>
            <option value="other">Other</option>
          </select>
          <button
            onClick={handleAddEvent}
            className="w-full px-4 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 text-white rounded-lg hover:from-cyan-700 hover:to-blue-700 transition-all duration-200 text-sm"
          >
            Add Event
          </button>
        </div>
      )}

      <div className="space-y-3">
        {todayEvents.map((event) => (
          <div
            key={event.id}
            className="p-3 bg-white/90 rounded-lg hover:shadow-md transition-all duration-200 group"
          >
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-semibold truncate text-sm">{event.title}</h3>
              <div className="flex items-center gap-2">
                <span className={`px-2 py-1 rounded-full text-xs ${
                  event.category === 'school' ? 'bg-cyan-100 text-cyan-800' :
                  event.category === 'personal' ? 'bg-green-100 text-green-800' :
                  event.category === 'health' ? 'bg-red-100 text-red-800' :
                  'bg-gray-100 text-gray-800'
                }`}>
                  {event.category}
                </span>
                <button
                  onClick={() => handleDeleteEvent(event.id)}
                  className="text-red-500 opacity-0 group-hover:opacity-100 transition-opacity duration-200"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
            <div className="text-gray-600 text-xs">
              {event.startTime} - {event.endTime}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Calendar;