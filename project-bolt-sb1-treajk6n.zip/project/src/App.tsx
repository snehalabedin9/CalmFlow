import React from 'react';
import { Waves } from 'lucide-react';
import MoodTracker from './components/MoodTracker';
import Journal from './components/Journal';
import Calendar from './components/Calendar';

function App() {
  return (
    <div className="min-h-screen bg-[url('https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&q=80')] bg-cover bg-center bg-fixed">
      <div className="min-h-screen bg-gradient-to-b from-cyan-900/10 via-transparent to-cyan-900/10">
        <header className="bg-gradient-to-r from-white/80 via-white/70 to-white/80 shadow-lg">
          <div className="max-w-5xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
            <div className="flex items-center gap-2">
              <Waves className="w-8 h-8 text-cyan-600" />
              <h1 className="text-2xl font-bold bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent">
                CalmFlow
              </h1>
            </div>
          </div>
        </header>

        <main className="max-w-5xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-6">
              <MoodTracker />
              <Journal />
            </div>
            <div>
              <Calendar />
            </div>
          </div>
        </main>

        <footer className="bg-gradient-to-r from-white/80 via-white/70 to-white/80 mt-12">
          <div className="max-w-5xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
            <p className="text-center bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent">
              CalmFlow - Find your inner peace
            </p>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default App;